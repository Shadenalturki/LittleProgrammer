 
	function openNav() {
	  document.querySelector("header").style.height = "550px";
	  document.querySelector("#closeBtn").style.display = "block";
	  document.querySelector("#menuBtn").style.display = "none";
	}

	function closeNav() {
	  document.querySelector("header").style.height = "125px";
	  document.querySelector("#closeBtn").style.display = "none";
	  document.querySelector("#menuBtn").style.display = "block";
	} 

	


   

	